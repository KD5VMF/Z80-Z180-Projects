CHESS8: RTC CLOCK, WHITE/BLACK THINKING TIME, ANTI-OSCILLATION

Open CHESS8.ASM in TMSAsmBuilder REV11. Build with bundled SjASMPlus.
Run CHESS8.COM on RomWBW CP/M.

The right panel shows RTC time (HH:MM:SS) and per-player cumulative thinking time (MM:SS) for the current game.
RTC is read using RomWBW HBIOS function 20h at FFF0h; clock displays --:--:-- if unavailable.
Thinking seconds update on observed RTC second transitions while the move search runs.
This is not a deep or tournament-strength chess engine. Repeat-move penalty and opening
development bonuses reduce, but cannot completely eliminate, looping play.

No physical hardware test completed.
